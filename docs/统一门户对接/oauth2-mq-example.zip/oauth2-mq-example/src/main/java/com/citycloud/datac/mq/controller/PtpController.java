package com.citycloud.datac.mq.controller;



import com.alibaba.fastjson.JSON;
import com.citycloud.datac.mq.dto.DepartmentMessageDTO;
import com.citycloud.datac.mq.dto.DeptUserDTO;
import com.citycloud.datac.mq.dto.UserMessageDTO;
import com.citycloud.datac.mq.jms.JmsPubSubProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description 推送消息
 * @Date 2020/1/8 11:03 AM
 * @Author liuyan
 **/
@RestController
@RequestMapping("/msg")
public class PtpController {

    @Autowired
    private JmsPubSubProducer jmsPubSubProducer;

    @GetMapping(value = "/createdSend")
    @ResponseBody
    public Map<String,Object> convertAndSend(){
        DepartmentMessageDTO deptment = new DepartmentMessageDTO();
        deptment.setDeptCode("mq部门编号");
        deptment.setCreatedTime(new Date());
        deptment.setVersion(1);
        deptment.setDeptName("mq部门");
        deptment.setDataStatus((short)1);
//        UserMessageDTO user = new UserMessageDTO();
//        user.setUserId(10001L);
//        user.setCreateTime(new Date());
//        user.setAddress("xxxxxx");
        DeptUserDTO dto = new DeptUserDTO();
        dto.setTime(new Date());
        dto.setOperation("created");
        dto.setDepts(Arrays.asList(deptment));
//        dto.setUsers(Arrays.asList(user));
//        dto.setVersion(1);
        Map<String,Object> result = new HashMap<>();
        result.put("code","200");
        result.put("message","推送成功");
        result.put("data",dto);
        //指定MQ的Topic，推送信息
        jmsPubSubProducer.sendObjectMessage("datac_user_dept_topic", JSON.toJSONString(result));
        return result;
    }

}
