package com.citycloud.datac.mq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.JmsProperties;
import org.springframework.boot.autoconfigure.jms.activemq.ActiveMQProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableConfigurationProperties({ ActiveMQProperties.class, JmsProperties.class })
@EnableJms
public class DatacMqDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatacMqDemoApplication.class, args);
    }

}
