package com.citycloud.datac.mq.dto;

import java.io.Serializable;

/**
 * @Description 用户关系推送
 * @Date 2020/1/12 11:56 AM
 * @Author liuyan
 **/

public class UserDeptRelationDTO implements Serializable {

    private static final long serialVersionUID = 8438838616636059561L;

    private Long userId;

    private Long deptId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }
}
