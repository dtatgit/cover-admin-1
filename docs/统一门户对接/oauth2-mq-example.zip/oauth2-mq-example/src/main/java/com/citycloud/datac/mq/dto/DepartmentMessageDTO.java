package com.citycloud.datac.mq.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description  部门信息同步信息体
 * @Date 2020/1/9 2:11 PM
 * @Author liuyan
 **/

public class DepartmentMessageDTO implements Serializable {


    private static final long serialVersionUID = 5823860397316471363L;
    /**站点ID*/
    private Long projectId;

    /**部门ID*/
    private Long deptId;
    /**部门名称*/
    private String deptName;
//    /**部门全称*/
//    private String fullPath;
//    /**机构ID*/
//    private Long groupId;
    /**父节点ID*/
    private Long pid;
    /**部门编号*/
    private String deptCode;
    /**部门排序号*/
    private Long orderNo;
    /**部门类型*/
    private Short deptType;
    /**联系人*/
    private String telephone;
    /**启用/禁用*/
    private Short dataStatus;
    /**修改版本*/
    private Integer version;
    /**创建时间*/
    private Date createdTime;

    /**描述*/
    private String remark;


    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public Long getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Long orderNo) {
        this.orderNo = orderNo;
    }

    public Short getDeptType() {
        return deptType;
    }

    public void setDeptType(Short deptType) {
        this.deptType = deptType;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Short getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(Short dataStatus) {
        this.dataStatus = dataStatus;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
