package com.citycloud.datac.mq.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description 部门信息
 * @Date 2020/1/8 2:57 PM
 * @Author liuyan
 **/

public class DeletedDeptUserDTO implements Serializable {

    private static final long serialVersionUID = 4194796923914991006L;

    private List<Long> deptId;

    private List<UserDeptRelationDTO> userDepts;

    private Long projectId;

    private Integer version;
    /**操作类型 create updated deleted */
    private String operation;

    private Date time;

    public List<Long> getDeptId() {
        return deptId;
    }

    public void setDeptId(List<Long> deptId) {
        this.deptId = deptId;
    }

    public List<UserDeptRelationDTO> getUserDepts() {
        return userDepts;
    }

    public void setUserDepts(List<UserDeptRelationDTO> userDepts) {
        this.userDepts = userDepts;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}

