package com.citycloud.datac.mq.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description 部门信息
 * @Date 2020/1/8 2:57 PM
 * @Author liuyan
 **/

public class DeptUserDTO implements Serializable {

    private static final long serialVersionUID = 4194796923914991006L;

    private List<DepartmentMessageDTO> depts;

    private List<UserMessageDTO> users;

    private Integer version;
    /**操作类型 created updated deleted */
    private String operation;

    private Date time;

    public List<DepartmentMessageDTO> getDepts() {
        return depts;
    }

    public void setDepts(List<DepartmentMessageDTO> depts) {
        this.depts = depts;
    }

    public List<UserMessageDTO> getUsers() {
        return users;
    }

    public void setUsers(List<UserMessageDTO> users) {
        this.users = users;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}
