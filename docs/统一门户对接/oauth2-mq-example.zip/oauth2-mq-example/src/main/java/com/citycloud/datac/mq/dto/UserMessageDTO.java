package com.citycloud.datac.mq.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description  用户信息推送信息体
 * @Date 2020/1/9 2:11 PM
 * @Author liuyan
 **/

public class UserMessageDTO implements Serializable {


    private static final long serialVersionUID = -6803250871996231293L;
    /**用户ID*/
    private Long userId;
    /**用户编号*/
    private String userNo;
    /**用户名*/
    private String userName;
    /**员工卡号*/
    private String cardNo;
    /**性别*/
    private Short sex;
    /**部门ID*/
    private Long deptId;
//    /**机构ID*/
//    private Long groupId;
    /**站点ID*/
    private Long projectId;
    /**手机号*/
    private String telephone;
    /**联系地址*/
    private String address;
    /**邮箱*/
    private String email;
    /**出生年月*/
    private Date birthday;
    /**创建时间*/
    private Date createTime;
    /**用户等级*/
    private Short userGrade;
    /**职务标识*/
    private Integer postId;
    /**用户类型*/
    private Short type;
    /**启用/停用*/
    private Boolean status;
    /**执行版本*/
    private Integer version;
    /**备注*/
    private String remark;
    /**办公室电话*/
    private String officeTel;
    /**头像路径*/
    private String iconFilePath;


    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Short getSex() {
        return sex;
    }

    public void setSex(Short sex) {
        this.sex = sex;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Short getUserGrade() {
        return userGrade;
    }

    public void setUserGrade(Short userGrade) {
        this.userGrade = userGrade;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public Short getType() {
        return type;
    }

    public void setType(Short type) {
        this.type = type;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getOfficeTel() {
        return officeTel;
    }

    public void setOfficeTel(String officeTel) {
        this.officeTel = officeTel;
    }

    public String getIconFilePath() {
        return iconFilePath;
    }

    public void setIconFilePath(String iconFilePath) {
        this.iconFilePath = iconFilePath;
    }
}
