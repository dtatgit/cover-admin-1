package com.citycloud.datac.mq.jms;

import org.apache.activemq.command.ActiveMQMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

/**
 * @Description  JMS 消息监听
 * @Date 2020/1/8 10:12 AM
 * @Author liuyan
 **/
@Component
public class PubSubListener {

    private static Logger log = LoggerFactory.getLogger(PubSubListener.class);

    /**
     * 部门人员增量监听
     * @param message
     * @param session
     * @throws Exception
     */
    @JmsListener(destination = "datac_user_dept_topic", containerFactory = "JmsTopicListenerContainerFactory")
    public void receive(Message message, Session session) throws Exception {
        toLog(message,"datac_user_dept_topic");
    }

    private void toLog(Message message,String destination) throws Exception{
        log.info(message.toString());
        if (message instanceof TextMessage){
            log.info("-----------------订阅信息>{}-------：{}",destination, ((TextMessage) message).getText());
        }else if(message instanceof ActiveMQMessage){
            log.info("-----------------订阅信息>{}-------：{}",destination, message);
        }
    }

    /**
     * 行政区划监听
     * @param message
     * @param session
     * @throws Exception
     */
    @JmsListener(destination = "datac_district_topic", containerFactory = "JmsTopicListenerContainerFactory")
    public void receiveDistrict(Message message, Session session) throws Exception {
        toLog(message,"datac_district_topic");
    }

}
