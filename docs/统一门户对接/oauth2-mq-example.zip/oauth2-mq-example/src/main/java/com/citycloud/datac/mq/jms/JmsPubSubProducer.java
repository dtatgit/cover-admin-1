package com.citycloud.datac.mq.jms;

import org.apache.activemq.command.ActiveMQTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @Description  JMS 消息生产者
 * @Date 2020/1/8 10:12 AM
 * @Author liuyan
 **/
@Component
public class JmsPubSubProducer {

    @Autowired
    @Qualifier("JmsMQTemplate")
    private JmsTemplate jmsTopicTemplate;
    //默认目的名称

    /**
     * topic发送消息
     * @param destinationName 目标名称
     * @param message 发送信息
     */
    public void sendObjectMessage(String destinationName,String message){
        ActiveMQTopic topic = new ActiveMQTopic(destinationName);
        jmsTopicTemplate.convertAndSend(topic,message);
//        jmsTopicTemplate.send(topic, session -> session.createObjectMessage(message));
    }


}
